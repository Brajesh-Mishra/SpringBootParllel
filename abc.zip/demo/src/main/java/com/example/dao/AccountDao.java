package com.example.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.example.bean.AccountHolder;
import com.example.bean.Transactions;
import com.example.bean.Wallet;

@Repository
public class AccountDao implements IAccountDao{

	@PersistenceContext
	EntityManager em;
	
	
	@Override
	public String createAccount(AccountHolder account) {
		 em.persist(account);
		 return "Account created successfully";
	}

	
	@Override 
	public AccountHolder withdrawAmount(String mobileNo, double amount){
		
	  AccountHolder account=em.find(AccountHolder.class,mobileNo);
	  
	  account.getWallet().setBalance(account.getWallet().getBalance()-amount);
	  account.getWallet().getListTransaction().add(new Transactions("Withdraw",amount));
	  em.merge(account); 
	  return account; 
	  
	} 
	  
	  
	  @Override 
	  public AccountHolder depositAmount(String mobileNo, double amount)
	 {
	  
	  AccountHolder account=em.find(AccountHolder.class,mobileNo);
	  
	  account.getWallet().setBalance(account.getWallet().getBalance()+amount);
	  account.getWallet().getListTransaction().add(new Transactions("Deposit",amount));
	  em.merge(account);
	  return account; 
	  }
	  
	  
	  @Override 
	  public double showBalance(String mobileNo){ 
	 AccountHolder account=em.find(AccountHolder.class,  mobileNo);
	 return  account.getWallet().getBalance();
	  
	  } 
	  
	  @Override 
	  public ArrayList<AccountHolder> fundTransfer(String senderMobileNo,String receiverMobileNo, double amount){ 
	AccountHolder senderAccount=em.find(AccountHolder.class,senderMobileNo);
	AccountHolder receiverAccount=em.find(AccountHolder.class,receiverMobileNo);
	  
	  senderAccount.getWallet().setBalance(senderAccount.getWallet().getBalance()-amount);
	  receiverAccount.getWallet().setBalance(receiverAccount.getWallet().getBalance()+amount); 
	  
	  senderAccount.getWallet().getListTransaction().add(new Transactions("Debited",amount));
	  receiverAccount.getWallet().getListTransaction().add(new Transactions("Credited",amount));
	  
	  em.merge(senderAccount);
	  em.merge(receiverAccount); 
	  
	  
	  ArrayList<AccountHolder> list=new ArrayList<AccountHolder>();
	  list.add(senderAccount);
	  list.add(receiverAccount);
	  return list; 
	  }
	  
	  @Override
	  public List<Transactions> printTtansaction(String mobileNo) {
	  
		  AccountHolder account=em.find(AccountHolder.class, mobileNo);
		  Wallet wallet=em.find(Wallet.class, account.getWallet().getWalletNo());
		  return  wallet.getListTransaction();
		  
		}
}

